function openMenu()
{
	document.getElementById("mySidenav").style.display = "block";
}