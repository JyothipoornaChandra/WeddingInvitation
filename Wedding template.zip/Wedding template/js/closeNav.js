function closenav()
{
	document.getElementById("mySidenav").style.display = "none";
	
}